# Leaf - Self-Discovery Course Platform

## Overview

Leaf is a 3-phase self-discovery and personal growth course platform that integrates AI-powered features. It offers courses focused on self-reflection, personal structure, and transformation, available individually or as a bundle. The platform uses a natural, organic theme with green/leaf tones throughout (primary color: HSL 142 50% 40%) and nature-inspired iconography (Leaf, Sprout, TreePine from lucide-react). The custom LeafLogo component (`client/src/components/leaf-logo.tsx`) renders an SVG leaf with white vein details and green stems. Brand text uses light green (`text-primary`).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite.
- **Routing**: Wouter for client-side routing.
- **State Management**: TanStack React Query for server state.
- **UI Components**: shadcn/ui built on Radix UI, styled with Tailwind CSS and CSS variables for theming.
- **Design System**: Natural green leaf theme (HSL 142), Inter for body, Plus Jakarta Sans for headings, 16px base font, 1.6 line-height, 12px border radius, nature-inspired icon palette (Sprout, TreePine, CalendarDays, Leaf).
- **Navigation Structure**: Three main tabs:
  - **Today** (default landing): Daily-focused dashboard with due habits, top 3 tasks, Q2 blocks, journal quick entry, quick tools
  - **Plan**: Vision board, monthly goal, habits overview, Eisenhower matrix links with inline planning wizard stepper
  - **Calendar** (`/journal`): Journal hub with morning/evening check-ins, journal calendar, plus links to Progress and Tools at the bottom
- **Key Features**:
  - **Goal Hierarchy System**: Integrates Quarterly, Monthly, and Daily goals. Includes a dedicated page for Monthly Goals and Quarterly Goals, and a dashboard card showing the hierarchical flow. Monthly goals have a required deadline date field displayed on Today and Plan pages.
  - **Goal-Setting Wizard** (`/goal-wizard`): 15-step self-guided "How to Set a Real Goal" exercise. Part 1 covers goal setting (strengths, precise goal definition, time horizon/deadline, success proof with metric/weekly behavior, best result with 15s visualization timer, inner obstacle with trigger/thought/emotion/behavior analysis, IF-THEN implementation plans). Part 2 covers mindset (values, prizes, fun). All fields required. Users without a complete monthly goal are automatically redirected here from the dashboard.
  - **Journaling**: Restructured Morning and Evening journals with detailed sections (e.g., Self-Awareness, Gratitude, Trigger Log, 80/20 Tracker). Data stored as JSON.
  - **Habit Tracking**: Recurring habits with day-of-week cadence, duration, 5 categories (Health=green/emerald, Wealth=yellow, Relationships=red/rose, Self-Development=blue, Happiness=white/slate), and daily tracking. Habits can be typed (goal/learning/maintenance). **Binary flag** (`is_binary` column, default false): Binary items (e.g., "take medication") have 2 levels: 0=Not Done, 1=Done (green). Non-binary items have 3 levels: 0=Not Done (red), 1=Minimum (yellow), 2=Full (green). **Click-through cycling** (not dropdown): Binary cycles blank→Done(green)→Skip(red,reason dialog)→blank; Non-binary cycles blank→Full(green)→Min(yellow)→Skip(red,reason dialog)→blank. Binary toggle available in habit dialog and Eisenhower entry creation. Progress metrics score binary level=1 as full completion. `habit_completions` table has `completion_level` (int 0-2) and `skip_reason` (varchar) columns. Same system applies to Eisenhower Q1/Q2 items. Each habit requires a "Motivating Reason" field.
  - **Voice Input**: Web Speech API integration via VoiceTextarea/VoiceInput components (`client/src/components/voice-input.tsx`). Available on all text fields across journals, goals, identity doc, habits, and dashboard. Mic button appears inline; gracefully hidden if browser doesn't support speech recognition. Falls back to MediaRecorder + OpenAI Whisper transcription via `/api/audio/transcribe` when Web Speech API is unavailable.
  - **Daily Tasks**: Up to 3 tasks per day with Eisenhower Matrix quadrant labels.
  - **Eisenhower Matrix**: Weekly priority planning with 5 categories (Health, Wealth, Relationships, Self-Development, Happiness) and goal alignment field for Q2 items. "Success Catalyst" flagging (formerly blocksGoal). Includes "Plan Week" wizard with 3-step guided flow: brain dump, classification, and details. AI-powered "Auto-fill with AI" button in brain dump step calls `/api/eisenhower/parse-tasks` to auto-populate quadrant, role, date, and time fields from natural language input. **Q2 Time Tracker** (questionnaire, not free-form): a) Did you start on time? Y/N, b) If N: delay minutes (15min increments dropdown), c) Delay reason (dropdown, 10 predefined), d) Did you complete required time? Y/N, e) If N: minutes less (15min increments). DB fields: `started_on_time`, `delay_minutes`, `delay_reason`, `completed_required_time`, `time_short_minutes`. Q2 Focus Minutes metric derives actual from these fields.
  - **EQ Module** (`/empathy`): Split into two tabs — **Prep** (pre-conversation: intention, leave-them-feeling goal, trigger risk IF-THEN, them hypothesis, reality-check question, reflection/validation line) and **Debrief** (post-conversation: observations, how I came across, how they likely felt, what matters to them, did I confirm, what they need, next action). Shared `empathy_exercises` table with `exercise_type` column ('prep' | 'debrief').
  - **Self-Development Tools**: Meditation and Emotional Processing modules.
  - **Regulation Now Page** (`/regulation`): Three quick regulation tools with expandable cards, circular timers, play/pause/reset.
  - **Quick Tools (Dashboard)**: Tool modals extracted to `client/src/components/tools/`. Includes: Emotional Containment (4-step FEEL→LABEL→REGULATE→MOVE, uses ExerciseModal with mood tracking), Trigger Log (`trigger-log-modal.tsx`, on-demand form: time/context/trigger/emotion+intensity/urge+intensity/whatIdid/outcome/recovery minutes, stored in `trigger_logs` table), Avoidance Tool (`avoidance-tool-modal.tsx`, on-demand form: avoiding what/delay/discomfort 1-5/smallest exposure/start now, stored in `avoidance_logs` table). Movement and Loved One tools replaced by Trigger Log and Avoidance Tool.
  - **Custom Tools**: Users can add up to 3 custom tools from their GPT course. Stored in `custom_tools` table. Duplicate name prevention server-side. Components in `client/src/components/tools/custom-tool-modal.tsx`.
  - **Mood Tracking**: 5-level mood scale (1-5) with emotion text captured before and after each exercise. Stored in `tool_usage_logs` table with CSV export. All tool usage is trackable via `/api/tool-usage` and exportable via `/api/tool-usage/export`.
  - **Journal Calendar**: Week view with horizontal grid. Habits sorted by timing (morning → daily → evening). Export with date range filters. Habits and scheduled items have 3-state tracking (completed/skipped/blank).
  - **Dashboard (Today)**: Redesigned vertical flow: 1-Year Vision → Q1-Q4 quarterly goals row → Monthly Promise → North Star (identity/values/intention with voice input) → Daily Habits (journals + habits with cycling status) → Weekly Items (Q2 focus + mini calendar) → Evening Reflection → Regulation Now link → Library link.
  - **Vision Board** (`/plan`): Single image upload stored as base64 in identity_documents table (visionBoardMain). Upload, replace, and remove functionality.
  - **Plan Wizard** (`/plan`): 5-step gated wizard (Vision→Quarterly→Monthly→Habits→Eisenhower) with step completion checks and navigation gating. Each step must be completed before the next unlocks.
  - **Plan Versioning**: Save/restore/clear plan data via `plan_versions` table. Snapshot stores identity doc, monthly goal, quarterly goal, and active habits as JSONB. Modes: save, save_and_copy, save_and_clear. Version list with restore/delete.
  - **Journaling as Habits**: AM/PM journal entries appear as system habits in dashboard's "Due Today" card with click-to-navigate and auto-complete status based on journal existence.
  - **Course Curriculum**: Collapsible phases with lesson overviews and video placeholders.
  - **Phase 3 Transformation**: Document upload for AI pattern analysis and downloadable reports.
  - **Navigation Framework**: Lightweight process navigation with two features:
    - **returnTo system** (`client/src/hooks/use-return-to.ts`): `useReturnTo(fallback)` hook reads `?returnTo=` query param from URL, validates it (must be internal path), provides `finish()` to navigate back. `buildProcessUrl(path, returnTo)` creates launch URLs. Used by goal-wizard, and launch links from dashboard/plan.
    - **Unsaved Changes Guard** (`client/src/hooks/use-unsaved-guard.tsx`): `UnsavedGuardProvider` wraps the app. Components call `useUnsavedGuard()` to get `register()/unregister()` for dirty state tracking, and `safeNavigate()` which shows Save/Discard/Cancel modal before navigating when dirty. Applied to goal-wizard and eisenhower wizard. All AppLayout nav links use `safeNavigate`. `beforeunload` handler fires when dirty.
    - **Process Registry** (`client/src/lib/process-registry.ts`): Lean metadata for all process flows (id, title, path, defaultReturnTo, requiresDirtyGuard). No route generation — routes still in App.tsx.

## Navigation Framework Rules

When adding or modifying any process flow, follow this checklist:

1. Register the process in `client/src/lib/process-registry.ts`
2. Launch links must use `buildProcessUrl(path, currentPath)` to embed returnTo
3. Completion must call `useReturnTo(fallback).finish()` to return to origin
4. All AppLayout nav links must use `safeNavigate()` — never raw `<Link>` or `setLocation()`
5. Full-page processes with data entry: register with `useUnsavedGuard()`
6. Modal processes with data entry: intercept dialog close with confirmation dialog
7. Run `npm run verify` after changes

See `.local/skills/process-framework/SKILL.md` for code patterns and examples.

### Backend Architecture
- **Framework**: Express.js with TypeScript and Node.js.
- **API Design**: RESTful endpoints under `/api/` using JSON payloads.
- **Authentication**: Replit Auth via OpenID Connect with Passport.js and PostgreSQL session store.
- **AI Integration**: OpenAI API (gpt-5.2) for chat and pattern analysis.
- **Build Process**: esbuild for server, Vite for client.

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM.
- **Key Tables**: `users`, `sessions`, `purchases`, `journals`, `chatMessages`, `eisenhower_entries`, `empathy_exercises`, `habits`, `habit_completions`, `tasks`, `monthly_goals`, `quarterly_goals`, `identity_documents`, `plan_versions`, `tool_usage_logs`, `custom_tools`.
- **Shared Types**: TypeScript types and Zod schemas shared between client and server.

### Key Design Patterns
- **Protected Routes**: Client-side `AuthenticatedRoute` component.
- **Streaming Responses**: AI chat and Phase 3 analysis for real-time delivery.

## External Dependencies

### Third-Party Services
- **Stripe**: Payment processing for course purchases.
- **OpenAI**: AI chat completions and pattern analysis (GPT-5.2).
- **Replit Auth**: User authentication and identity management.

### Database
- **PostgreSQL**: Primary data store.
- **Drizzle ORM**: Type-safe database queries.

### Key npm Packages
- `express`, `express-session`
- `drizzle-orm`, `drizzle-zod`
- `@tanstack/react-query`
- `openai`
- `stripe`
- `passport`, `openid-client`
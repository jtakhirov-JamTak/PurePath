import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, registerAuthRoutes } from "./replit_integrations/auth";
import { getUncachableStripeClient, getStripePublishableKey } from "./stripeClient";
import { COURSES, type CourseType, HABIT_CATEGORIES } from "@shared/schema";
import OpenAI from "openai";
import { format } from "date-fns";
import multer from "multer";
import fs from "fs";
import rateLimit from "express-rate-limit";

const aiRateLimit = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  message: { error: "Too many AI requests. Please wait a minute before trying again." },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: any) => req.user?.claims?.sub || "anonymous",
});

const transcriptionRateLimit = rateLimit({
  windowMs: 60 * 1000,
  max: 5,
  message: { error: "Too many transcription requests. Please wait a minute." },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: any) => req.user?.claims?.sub || "anonymous",
});

const exportRateLimit = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  message: { error: "Too many export requests. Please wait a minute." },
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: any) => req.user?.claims?.sub || "anonymous",
});
import {
  createEisenhowerSchema, updateEisenhowerSchema,
  createEmpathySchema, updateEmpathySchema,
  createHabitSchema, updateHabitSchema,
  createHabitCompletionSchema,
  createTaskSchema, updateTaskSchema,
  createMeditationInsightSchema,
  createJournalSchema,
  createToolUsageSchema, updateToolUsageSchema,
  createCustomToolSchema, updateCustomToolSchema,
  chatMessageSchema, phase3AnalyzeSchema,
  visionBoardSchema, checkoutSchema,
  createTriggerLogSchema, createAvoidanceLogSchema,
} from "./validation";

const upload = multer({ dest: "/tmp/audio-uploads", limits: { fileSize: 10 * 1024 * 1024 } });

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

const SELF_DISCOVERY_SYSTEM_PROMPT = `You are a compassionate and insightful self-discovery guide. Your role is to help users explore their inner world, understand themselves better, and grow as individuals.

Guidelines:
- Ask thoughtful, open-ended questions that encourage deep reflection
- Listen actively and respond with empathy
- Help users identify patterns in their thoughts and behaviors
- Encourage self-compassion and growth mindset
- Provide insights without being prescriptive
- Create a safe, non-judgmental space for exploration
- Use techniques from various therapeutic approaches (CBT, mindfulness, positive psychology)
- Help users connect with their values, strengths, and aspirations

Remember: You're a guide, not a therapist. Encourage professional help for serious mental health concerns.`;

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  await setupAuth(app);
  registerAuthRoutes(app);

  app.get("/api/purchases", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const purchases = await storage.getPurchasesByUser(userId);
      res.json(purchases);
    } catch (error) {
      console.error("Error fetching purchases:", error);
      res.status(500).json({ error: "Failed to fetch purchases" });
    }
  });

  app.post("/api/checkout", isAuthenticated, async (req: any, res: Response) => {
    try {
      const parsed = checkoutSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      const userEmail = req.user.claims.email;
      const { courseType } = parsed.data;

      if (!COURSES[courseType]) {
        return res.status(400).json({ error: "Invalid course type" });
      }

      const course = COURSES[courseType];
      const stripe = await getUncachableStripeClient();
      
      // Use stable Price ID from env vars if available (production-ready)
      // Otherwise fallback to inline price_data (development)
      const stripePriceId = process.env[course.stripePriceEnvVar];
      
      const lineItems = stripePriceId
        ? [{ price: stripePriceId, quantity: 1 }]
        : [{
            price_data: {
              currency: "usd",
              product_data: {
                name: course.name,
                description: course.description,
              },
              unit_amount: course.price,
            },
            quantity: 1,
          }];

      const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        mode: "payment",
        customer_email: userEmail,
        line_items: lineItems,
        metadata: {
          userId,
          courseType,
        },
        success_url: `${req.protocol}://${req.get("host")}/checkout/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${req.protocol}://${req.get("host")}/checkout/cancel`,
      });

      res.json({ url: session.url });
    } catch (error) {
      console.error("Checkout error:", error);
      res.status(500).json({ error: "Failed to create checkout session" });
    }
  });

  app.post("/api/stripe/webhook", async (req: Request, res: Response) => {
    try {
      const stripe = await getUncachableStripeClient();
      const sig = req.headers["stripe-signature"];
      
      if (!sig) {
        return res.status(400).json({ error: "Missing signature" });
      }

      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
      
      let event;
      if (webhookSecret) {
        event = stripe.webhooks.constructEvent(req.rawBody as Buffer, sig, webhookSecret);
      } else {
        event = req.body;
      }

      if (event.type === "checkout.session.completed") {
        const session = event.data.object;
        const { userId, courseType } = session.metadata || {};

        if (userId && courseType) {
          const { created } = await storage.createPurchaseIfNotExists({
            userId,
            courseType,
            stripeSessionId: session.id,
            stripePaymentId: session.payment_intent as string,
            amount: session.amount_total || 0,
            status: "completed",
          });
          
          if (created) {
            console.log(`Purchase created for user ${userId}, course ${courseType}`);
          } else {
            console.log(`Duplicate webhook ignored for session ${session.id}`);
          }
        }
      }

      res.json({ received: true });
    } catch (error) {
      console.error("Webhook error:", error);
      res.status(400).json({ error: "Webhook error" });
    }
  });

  app.get("/api/journals", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      
      const hasAccess = await storage.hasCourseAccess(userId, "course2");
      if (!hasAccess) {
        return res.status(403).json({ error: "Course access required" });
      }

      const journals = await storage.getJournalsByUser(userId);
      res.json(journals);
    } catch (error) {
      console.error("Error fetching journals:", error);
      res.status(500).json({ error: "Failed to fetch journals" });
    }
  });

  app.get("/api/journals/:date/:session", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { date, session } = req.params;

      const hasAccess = await storage.hasCourseAccess(userId, "course2");
      if (!hasAccess) {
        return res.status(403).json({ error: "Course access required" });
      }

      const journal = await storage.getJournal(userId, date, session);
      res.json(journal || null);
    } catch (error) {
      console.error("Error fetching journal:", error);
      res.status(500).json({ error: "Failed to fetch journal" });
    }
  });

  app.post("/api/journals", isAuthenticated, async (req: any, res: Response) => {
    try {
      const parsed = createJournalSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;

      const hasAccess = await storage.hasCourseAccess(userId, "course2");
      if (!hasAccess) {
        return res.status(403).json({ error: "Course access required" });
      }

      const journal = await storage.createOrUpdateJournal({
        userId,
        ...parsed.data,
      });

      if (parsed.data.session === "evening" && parsed.data.tomorrowGoals) {
        try {
          const content = parsed.data.content ? JSON.parse(parsed.data.content) : {};
          const tomorrowStep = parsed.data.tomorrowGoals.trim();
          if (tomorrowStep) {
            const journalDate = new Date(parsed.data.date + "T12:00:00");
            const tomorrow = new Date(journalDate);
            tomorrow.setDate(tomorrow.getDate() + 1);
            const tomorrowStr = format(tomorrow, "yyyy-MM-dd");
            const dayOfWeek = tomorrow.getDay();
            const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
            const weekStartDate = new Date(tomorrow);
            weekStartDate.setDate(weekStartDate.getDate() + mondayOffset);
            const weekStartStr = format(weekStartDate, "yyyy-MM-dd");
            const rawTime = content.tomorrowStepTime || "08:00";
            const [hh, mm] = rawTime.split(":").map(Number);
            const ampm = hh >= 12 ? "PM" : "AM";
            const h12 = hh === 0 ? 12 : hh > 12 ? hh - 12 : hh;
            const displayTime = `${h12}:${String(mm).padStart(2, "0")} ${ampm}`;
            await storage.createEisenhowerEntry({
              userId,
              task: tomorrowStep,
              weekStart: weekStartStr,
              role: "self-development",
              quadrant: "q1",
              scheduledDate: tomorrowStr,
              scheduledStartTime: rawTime,
              scheduledTime: displayTime,
              isBinary: true,
            });
          }
        } catch (e) {
          console.error("Error auto-creating Q1 from evening journal:", e);
        }
      }

      res.json(journal);
    } catch (error) {
      console.error("Error saving journal:", error);
      res.status(500).json({ error: "Failed to save journal" });
    }
  });

  app.get("/api/journals/export", isAuthenticated, exportRateLimit, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const startDate = req.query.startDate as string | undefined;
      const endDate = req.query.endDate as string | undefined;

      const hasAccess = await storage.hasCourseAccess(userId, "course2");
      if (!hasAccess) {
        return res.status(403).json({ error: "Course access required" });
      }

      let journals = await storage.getJournalsByUser(userId);
      if (startDate) journals = journals.filter(j => j.date >= startDate);
      if (endDate) journals = journals.filter(j => j.date <= endDate);

      const habits = await storage.getHabitsByUser(userId);
      const rangeStart = startDate || "2000-01-01";
      const rangeEnd = endDate || "2099-12-31";
      const completions = await storage.getHabitCompletionsForRange(userId, rangeStart, rangeEnd);

      const eisenhower = await storage.getEisenhowerEntriesByUser(userId);
      let filteredEisenhower = eisenhower.filter(e => e.quadrant === "q2" && e.deadline);
      if (startDate) filteredEisenhower = filteredEisenhower.filter(e => e.deadline! >= startDate);
      if (endDate) filteredEisenhower = filteredEisenhower.filter(e => e.deadline! <= endDate);

      const habitMap = new Map(habits.map(h => [h.id, h.name]));
      
      let content = "# Journal Calendar Export\n\n";
      if (startDate || endDate) {
        content += `Date Range: ${startDate || "beginning"} to ${endDate || "present"}\n\n`;
      }

      content += "---\n\n";
      content += "## Journal Entries\n\n";
      
      journals.forEach((journal) => {
        content += `### ${journal.date} - ${journal.session.charAt(0).toUpperCase() + journal.session.slice(1)}\n\n`;
        
        if (journal.content) {
          try {
            const parsed = JSON.parse(journal.content);
            if (journal.session === "morning") {
              if (parsed.intention) content += `**Intention:** ${parsed.intention}\n`;
              if (parsed.gratitude) content += `**Gratitude:** ${parsed.gratitude}\n`;
              if (parsed.joy) content += `**Joy:** ${parsed.joy}\n`;
              if (parsed.enjoy) content += `**Enjoy:** ${parsed.enjoy}\n`;
              if (parsed.avoidance) content += `**Avoidance:** ${parsed.avoidance}\n`;
              if (parsed.understanding) content += `**Understanding:** ${parsed.understandingEmotion ? `(${parsed.understandingEmotion}) ` : ""}${parsed.understanding}\n`;
              if (parsed.counterEvidence) content += `**Counter-Evidence:** ${parsed.counterEvidence}\n`;
              if (parsed.courageAction) content += `**Courage Action:** ${parsed.courageAction}\n`;
              if (parsed.stress) content += `**Stress:** ${parsed.stress}\n`;
              if (parsed.perspectiveShift) content += `**Perspective Shift:** ${parsed.perspectiveShift}\n`;
            } else {
              if (parsed.review) content += `**Review:** ${parsed.review}\n`;
              if (parsed.feedback) content += `**Feedback:** ${parsed.feedback}\n`;
              if (parsed.insight) content += `**Insight:** ${parsed.insight}\n`;
              if (parsed.lesson) content += `**Lesson:** ${parsed.lesson}\n`;
              if (parsed.trigger) content += `**Trigger:** ${parsed.trigger}\n`;
              if (parsed.triggerStory) content += `**Story:** ${parsed.triggerStory}\n`;
              if (parsed.triggerImpulse) content += `**Impulse:** ${parsed.triggerImpulse}\n`;
              if (parsed.triggerEmotion) content += `**Emotion:** ${parsed.triggerEmotion}${parsed.triggerEmotionLevel ? ` (${parsed.triggerEmotionLevel}/10)` : ""}\n`;
              if (parsed.triggerUrge) content += `**Urge:** ${parsed.triggerUrge}${parsed.triggerUrgeLevel ? ` (${parsed.triggerUrgeLevel}/10)` : ""}\n`;
              if (parsed.triggerBehavior) content += `**Behavior:** ${parsed.triggerBehavior}\n`;
              if (parsed.triggerOutcome) content += `**Outcome:** ${parsed.triggerOutcome}\n`;
              if (parsed.triggerNextTime) content += `**Next Time:** ${parsed.triggerNextTime}\n`;
              if (parsed.satisfied) content += `**Satisfied With:** ${parsed.satisfied}\n`;
              if (parsed.dissatisfied) content += `**Dissatisfied With:** ${parsed.dissatisfied}\n`;
              if (parsed.shutdownEnough) content += `**Today Was Enough Because:** ${parsed.shutdownEnough}\n`;
              if (parsed.shutdownTomorrow) content += `**Tomorrow's First Step:** ${parsed.shutdownTomorrow}\n`;
            }
          } catch {
            if (journal.gratitude) content += `**Gratitude:** ${journal.gratitude}\n`;
            if (journal.intentions) content += `**Intentions:** ${journal.intentions}\n`;
            if (journal.highlights) content += `**Highlights:** ${journal.highlights}\n`;
            if (journal.reflections) content += `**Reflections:** ${journal.reflections}\n`;
            if (journal.challenges) content += `**Challenges:** ${journal.challenges}\n`;
            if (journal.tomorrowGoals) content += `**Tomorrow's Goals:** ${journal.tomorrowGoals}\n`;
          }
        }
        content += "\n";
      });

      if (completions.length > 0) {
        content += "---\n\n## Habit Tracking\n\n";
        const byDate = new Map<string, Array<{ name: string; status: string }>>();
        completions.forEach((c: any) => {
          const name = habitMap.get(c.habitId) || `Habit #${c.habitId}`;
          if (!byDate.has(c.date)) byDate.set(c.date, []);
          byDate.get(c.date)!.push({ name, status: c.status || "completed" });
        });
        const sortedDates = Array.from(byDate.keys()).sort();
        sortedDates.forEach(date => {
          content += `### ${date}\n`;
          byDate.get(date)!.forEach(h => {
            const icon = h.status === "completed" ? "[x]" : "[-]";
            content += `- ${icon} ${h.name} (${h.status})\n`;
          });
          content += "\n";
        });
      }

      if (filteredEisenhower.length > 0) {
        content += "---\n\n## Scheduled Items (Eisenhower Q2)\n\n";
        filteredEisenhower.forEach(e => {
          const status = e.completed ? "[x]" : "[ ]";
          content += `- ${status} ${e.task} (${e.role}, deadline: ${e.deadline})${e.scheduledTime ? ` @ ${e.scheduledTime}` : ""}\n`;
        });
        content += "\n";
      }

      res.setHeader("Content-Type", "text/plain");
      res.setHeader("Content-Disposition", `attachment; filename=journal-export${startDate ? `-${startDate}` : ""}${endDate ? `-to-${endDate}` : ""}.txt`);
      res.send(content);
    } catch (error) {
      console.error("Error exporting journals:", error);
      res.status(500).json({ error: "Failed to export journals" });
    }
  });

  app.get("/api/chat/messages", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;

      const hasAccess = await storage.hasCourseAccess(userId, "course1");
      if (!hasAccess) {
        return res.status(403).json({ error: "Course access required" });
      }

      const messages = await storage.getChatMessagesByUser(userId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching chat messages:", error);
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  app.post("/api/chat/messages", isAuthenticated, aiRateLimit, async (req: any, res: Response) => {
    try {
      const parsed = chatMessageSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      const { content } = parsed.data;

      const hasAccess = await storage.hasCourseAccess(userId, "course1");
      if (!hasAccess) {
        return res.status(403).json({ error: "Course access required" });
      }

      await storage.createChatMessage({
        userId,
        role: "user",
        content,
      });

      const history = await storage.getChatMessagesByUser(userId);
      const currentMonth = format(new Date(), "yyyy-MM");
      const monthlyGoal = await storage.getMonthlyGoal(userId, currentMonth);
      let systemPrompt = SELF_DISCOVERY_SYSTEM_PROMPT;
      const hasGoal = monthlyGoal?.goalWhat || monthlyGoal?.goalStatement;
      if (hasGoal) {
        systemPrompt += `\n\nIMPORTANT CONTEXT — The user's current monthly goal:`;
        if (monthlyGoal.goalWhat) systemPrompt += `\nWhat: ${monthlyGoal.goalWhat}`;
        if (monthlyGoal.goalWhen) systemPrompt += `\nWhen: ${monthlyGoal.goalWhen}`;
        if (monthlyGoal.goalWhere) systemPrompt += `\nWhere: ${monthlyGoal.goalWhere}`;
        if (monthlyGoal.goalHow) systemPrompt += `\nHow: ${monthlyGoal.goalHow}`;
        if (monthlyGoal.goalStatement) systemPrompt += `\nGoal summary: ${monthlyGoal.goalStatement}`;
        if (monthlyGoal.value) systemPrompt += `\nValue it serves: ${monthlyGoal.value}`;
        if (monthlyGoal.strengths) systemPrompt += `\nStrengths: ${monthlyGoal.strengths}`;
        if (monthlyGoal.blockingHabit) systemPrompt += `\nBlocking habit: ${monthlyGoal.blockingHabit}`;
        if (monthlyGoal.habitAddress) systemPrompt += `\nPlan to address it: ${monthlyGoal.habitAddress}`;
        if (monthlyGoal.successProof) systemPrompt += `\nSuccess proof: ${monthlyGoal.successProof}`;
        if (monthlyGoal.proofMetric) systemPrompt += `\nMetric: ${monthlyGoal.proofMetric}`;
        if (monthlyGoal.weeklyBehavior) systemPrompt += `\nWeekly behavior: ${monthlyGoal.weeklyBehavior}`;
        if (monthlyGoal.bestResult) systemPrompt += `\nBest result: ${monthlyGoal.bestResult}`;
        if (monthlyGoal.innerObstacle) systemPrompt += `\nInner obstacle: ${monthlyGoal.innerObstacle}`;
        if (monthlyGoal.obstacleTrigger) systemPrompt += `\nObstacle trigger: ${monthlyGoal.obstacleTrigger}`;
        if (monthlyGoal.obstacleThought) systemPrompt += `\nObstacle thought: ${monthlyGoal.obstacleThought}`;
        if (monthlyGoal.obstacleEmotion) systemPrompt += `\nObstacle emotion: ${monthlyGoal.obstacleEmotion}`;
        if (monthlyGoal.obstacleBehavior) systemPrompt += `\nObstacle behavior: ${monthlyGoal.obstacleBehavior}`;
        if (monthlyGoal.ifThenPlan1) systemPrompt += `\nIF-THEN plan 1: ${monthlyGoal.ifThenPlan1}`;
        if (monthlyGoal.ifThenPlan2) systemPrompt += `\nIF-THEN plan 2: ${monthlyGoal.ifThenPlan2}`;
        systemPrompt += `\nWeave this goal context naturally into your coaching when relevant. Don't force it, but be aware of it.`;
      }
      const messages = [
        { role: "system" as const, content: systemPrompt },
        ...history.slice(-20).map((m) => ({
          role: m.role as "user" | "assistant",
          content: m.content,
        })),
      ];

      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");

      const stream = await openai.chat.completions.create({
        model: "gpt-5.2",
        messages,
        stream: true,
        max_completion_tokens: 2048,
      });

      let fullResponse = "";

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || "";
        if (content) {
          fullResponse += content;
          res.write(`data: ${JSON.stringify({ content })}\n\n`);
        }
      }

      await storage.createChatMessage({
        userId,
        role: "assistant",
        content: fullResponse,
      });

      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
    } catch (error) {
      console.error("Chat error:", error);
      if (res.headersSent) {
        res.write(`data: ${JSON.stringify({ error: "Chat failed" })}\n\n`);
        res.end();
      } else {
        res.status(500).json({ error: "Failed to send message" });
      }
    }
  });

  app.post("/api/billing/refresh", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const stripe = await getUncachableStripeClient();

      const purchases = await storage.getPurchasesByUser(userId);
      
      if (purchases.length === 0) {
        return res.json({ 
          updated: false, 
          message: "No purchases found. If you just completed a payment, please wait a moment and try again." 
        });
      }

      let updated = false;
      
      for (const purchase of purchases) {
        if (purchase.stripeSessionId) {
          try {
            const session = await stripe.checkout.sessions.retrieve(purchase.stripeSessionId);
            
            if (session.payment_status === "paid" && purchase.status !== "completed") {
              await storage.updatePurchaseStatus(purchase.id, "completed");
              updated = true;
            }
          } catch (stripeError) {
            console.log(`Could not retrieve session ${purchase.stripeSessionId}:`, stripeError);
          }
        }
      }

      res.json({ 
        updated, 
        message: updated 
          ? "Your access has been refreshed successfully." 
          : "Your access is already up to date."
      });
    } catch (error) {
      console.error("Billing refresh error:", error);
      res.status(500).json({ error: "Failed to refresh access" });
    }
  });

  // ==================== EISENHOWER MATRIX ====================
  
  app.get("/api/eisenhower", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const entries = await storage.getEisenhowerEntriesByUser(userId);
      res.json(entries);
    } catch (error) {
      console.error("Error fetching eisenhower entries:", error);
      res.status(500).json({ error: "Failed to fetch entries" });
    }
  });

  app.get("/api/eisenhower/week/:weekStart", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { weekStart } = req.params;
      const entries = await storage.getEisenhowerEntriesForWeek(userId, weekStart);
      res.json(entries);
    } catch (error) {
      console.error("Error fetching weekly entries:", error);
      res.status(500).json({ error: "Failed to fetch entries" });
    }
  });

  app.post("/api/eisenhower", isAuthenticated, async (req: any, res: Response) => {
    try {
      const parsed = createEisenhowerSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      const { task, weekStart } = parsed.data;
      if (task && weekStart) {
        const existing = await storage.getEisenhowerEntriesForWeek(userId, weekStart);
        const duplicate = existing.find(e => e.task.toLowerCase() === task.trim().toLowerCase());
        if (duplicate) {
          return res.status(409).json({ error: `You already have a task named "${duplicate.task}" this week` });
        }
      }
      const entry = await storage.createEisenhowerEntry({ userId, ...parsed.data });
      res.json(entry);
    } catch (error) {
      console.error("Error creating entry:", error);
      res.status(500).json({ error: "Failed to create entry" });
    }
  });

  app.patch("/api/eisenhower/:id", isAuthenticated, async (req: any, res: Response) => {
    try {
      const parsed = updateEisenhowerSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const existing = await storage.getEisenhowerEntriesByUser(userId);
      const record = existing.find(r => r.id === parseInt(id));
      if (!record) {
        return res.status(403).json({ error: "Not authorized" });
      }
      const body = { ...parsed.data };
      if (body.status !== undefined) {
        body.completed = body.status === "completed";
      } else if (body.completed !== undefined) {
        body.status = body.completed ? "completed" : null;
      }
      const entry = await storage.updateEisenhowerEntry(parseInt(id), body);
      res.json(entry);
    } catch (error) {
      console.error("Error updating entry:", error);
      res.status(500).json({ error: "Failed to update entry" });
    }
  });

  app.delete("/api/eisenhower/:id", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const existing = await storage.getEisenhowerEntriesByUser(userId);
      const record = existing.find(r => r.id === parseInt(id));
      if (!record) {
        return res.status(403).json({ error: "Not authorized" });
      }
      await storage.deleteEisenhowerEntry(parseInt(id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting entry:", error);
      res.status(500).json({ error: "Failed to delete entry" });
    }
  });

  app.get("/api/eisenhower/export", isAuthenticated, exportRateLimit, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const entries = await storage.getEisenhowerEntriesByUser(userId);
      
      let csv = "Week Start,Role,Task,Quadrant,Deadline,Time Estimate,Decision,Scheduled Time,Completed\n";
      entries.forEach(e => {
        csv += `${e.weekStart},${e.role},"${e.task}",${e.quadrant},${e.deadline || ""},${e.timeEstimate || ""},${e.decision || ""},${e.scheduledTime || ""},${e.completed}\n`;
      });

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=eisenhower-matrix.csv");
      res.send(csv);
    } catch (error) {
      console.error("Error exporting eisenhower:", error);
      res.status(500).json({ error: "Failed to export" });
    }
  });

  // ==================== EMPATHY EXERCISES ====================
  
  app.get("/api/empathy", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const exercises = await storage.getEmpathyExercisesByUser(userId);
      res.json(exercises);
    } catch (error) {
      console.error("Error fetching empathy exercises:", error);
      res.status(500).json({ error: "Failed to fetch exercises" });
    }
  });

  app.post("/api/empathy", isAuthenticated, async (req: any, res: Response) => {
    try {
      const parsed = createEmpathySchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      const exercise = await storage.createEmpathyExercise({ userId, ...parsed.data });
      res.json(exercise);
    } catch (error) {
      console.error("Error creating exercise:", error);
      res.status(500).json({ error: "Failed to create exercise" });
    }
  });

  app.patch("/api/empathy/:id", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const existing = await storage.getEmpathyExercisesByUser(userId);
      const record = existing.find(r => r.id === parseInt(id));
      if (!record) {
        return res.status(403).json({ error: "Not authorized" });
      }
      const parsedBody = updateEmpathySchema.safeParse(req.body);
      if (!parsedBody.success) {
        return res.status(400).json({ error: parsedBody.error.issues[0].message });
      }
      const exercise = await storage.updateEmpathyExercise(parseInt(id), parsedBody.data);
      res.json(exercise);
    } catch (error) {
      console.error("Error updating exercise:", error);
      res.status(500).json({ error: "Failed to update exercise" });
    }
  });

  app.delete("/api/empathy/:id", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const existing = await storage.getEmpathyExercisesByUser(userId);
      const record = existing.find(r => r.id === parseInt(id));
      if (!record) {
        return res.status(403).json({ error: "Not authorized" });
      }
      await storage.deleteEmpathyExercise(parseInt(id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting exercise:", error);
      res.status(500).json({ error: "Failed to delete exercise" });
    }
  });

  app.get("/api/empathy/export", isAuthenticated, exportRateLimit, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const exercises = await storage.getEmpathyExercisesByUser(userId);
      
      let csv = "Type,Date,Who,Context,Their Emotional State,My Emotional State,Facts Observed,How I Came Across,How They Likely Felt,What Matters to Them,What They Need,Next Action,Did Confirm,Intention,Leave Them Feeling,Trigger Risk IF-THEN,Them Hypothesis,Reality Check Question,Reflection Validation\n";
      exercises.forEach(e => {
        csv += `"${e.exerciseType || "debrief"}",${e.date},"${e.who}","${e.context || ""}","${e.theirEmotionalState || ""}","${e.myEmotionalState || ""}","${e.factsObserved || ""}","${e.howICameAcross || ""}","${e.howTheyLikelyFelt || ""}","${e.whatMattersToThem || ""}","${e.whatTheyNeed || ""}","${e.nextAction || ""}","${e.didConfirm || ""}","${e.intention || ""}","${e.leaveThemFeeling || ""}","${e.triggerRiskIfThen || ""}","${e.themHypothesis || ""}","${e.realityCheckQuestion || ""}","${e.reflectionValidation || ""}"\n`;
      });

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=empathy-exercises.csv");
      res.send(csv);
    } catch (error) {
      console.error("Error exporting empathy:", error);
      res.status(500).json({ error: "Failed to export" });
    }
  });

  // ==================== HABITS ====================
  
  app.get("/api/habits", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const habits = await storage.getHabitsByUser(userId);
      res.json(habits);
    } catch (error) {
      console.error("Error fetching habits:", error);
      res.status(500).json({ error: "Failed to fetch habits" });
    }
  });

  app.post("/api/habits", isAuthenticated, async (req: any, res: Response) => {
    try {
      const parsed = createHabitSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      
      const existing = await storage.getHabitsByUser(userId);
      const activeHabits = existing.filter(h => h.active);

      if (activeHabits.length >= 6) {
        return res.status(400).json({ error: "Maximum 6 active habits allowed" });
      }

      const name = parsed.data.name;
      if (!name) {
        return res.status(400).json({ error: "Habit name is required" });
      }
      const duplicate = activeHabits.find(h => h.name.toLowerCase() === name.toLowerCase());
      if (duplicate) {
        return res.status(409).json({ error: `You already have an active habit named "${duplicate.name}"` });
      }

      const { category, ...rest } = parsed.data;
      const validCategory = category && category in HABIT_CATEGORIES ? category : "health";
      const habit = await storage.createHabit({ userId, category: validCategory, ...rest, name });
      res.json(habit);
    } catch (error) {
      console.error("Error creating habit:", error);
      res.status(500).json({ error: "Failed to create habit" });
    }
  });

  app.patch("/api/habits/:id", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const existing = await storage.getHabitsByUser(userId);
      const record = existing.find(r => r.id === parseInt(id));
      if (!record) {
        return res.status(403).json({ error: "Not authorized" });
      }
      const parsedBody = updateHabitSchema.safeParse(req.body);
      if (!parsedBody.success) {
        return res.status(400).json({ error: parsedBody.error.issues[0].message });
      }
      const habit = await storage.updateHabit(parseInt(id), parsedBody.data);
      res.json(habit);
    } catch (error) {
      console.error("Error updating habit:", error);
      res.status(500).json({ error: "Failed to update habit" });
    }
  });

  app.delete("/api/habits/:id", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const existing = await storage.getHabitsByUser(userId);
      const record = existing.find(r => r.id === parseInt(id));
      if (!record) {
        return res.status(403).json({ error: "Not authorized" });
      }
      await storage.deleteHabit(parseInt(id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting habit:", error);
      res.status(500).json({ error: "Failed to delete habit" });
    }
  });

  app.post("/api/habits/reorder", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { items } = req.body;
      if (!Array.isArray(items)) {
        return res.status(400).json({ error: "items must be an array" });
      }
      const existing = await storage.getHabitsByUser(userId);
      const existingIds = new Set(existing.map(h => h.id));
      for (const item of items) {
        if (typeof item.id !== "number" || typeof item.sortOrder !== "number") continue;
        if (!existingIds.has(item.id)) continue;
        const updates: any = { sortOrder: item.sortOrder };
        if (item.timing && ["morning", "afternoon", "evening"].includes(item.timing)) {
          updates.timing = item.timing;
        }
        await storage.updateHabit(item.id, updates);
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error reordering habits:", error);
      res.status(500).json({ error: "Failed to reorder habits" });
    }
  });

  app.post("/api/eisenhower/reorder", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { items } = req.body;
      if (!Array.isArray(items)) {
        return res.status(400).json({ error: "items must be an array" });
      }
      const existing = await storage.getEisenhowerEntriesByUser(userId);
      const existingIds = new Set(existing.map(e => e.id));
      for (const item of items) {
        if (typeof item.id !== "number" || typeof item.sortOrder !== "number") continue;
        if (!existingIds.has(item.id)) continue;
        const updates: any = { sortOrder: item.sortOrder };
        if (item.timeRange && ["morning", "afternoon", "evening"].includes(item.timeRange)) {
          updates.timeRange = item.timeRange;
        }
        if (item.scheduledDate && typeof item.scheduledDate === "string") {
          updates.scheduledDate = item.scheduledDate;
        }
        await storage.updateEisenhowerEntry(item.id, updates);
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error reordering entries:", error);
      res.status(500).json({ error: "Failed to reorder entries" });
    }
  });

  app.post("/api/eisenhower/parse-tasks", isAuthenticated, aiRateLimit, async (req: any, res: Response) => {
    try {
      const { tasks, weekStart } = req.body;
      if (!Array.isArray(tasks) || tasks.length === 0) {
        return res.status(400).json({ error: "tasks must be a non-empty array" });
      }
      if (tasks.length > 20) {
        return res.status(400).json({ error: "Maximum 20 tasks at a time" });
      }

      const weekDate = new Date(weekStart + "T00:00:00");
      const weekDays: Record<string, string> = {};
      const dayNames = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
      for (let i = 0; i < 7; i++) {
        const d = new Date(weekDate);
        d.setDate(d.getDate() + i);
        weekDays[dayNames[d.getDay()]] = format(d, "yyyy-MM-dd");
      }

      const systemPrompt = `You are a task parsing assistant. The user will give you a list of tasks from a weekly brain dump. For each task, extract structured data.

The current week starts on ${weekStart}. The days of this week are:
${Object.entries(weekDays).map(([day, date]) => `${day}: ${date}`).join("\n")}

For each task, return a JSON object with these fields:
- "task": the cleaned-up task name (concise, action-oriented)
- "quadrant": one of "q1" (urgent & important - do now), "q2" (important, not urgent - schedule), "q3" (urgent, not important - delegate), "q4" (not urgent, not important - avoid). Default to "q2" if unclear.
- "role": one of "health", "wealth", "relationships", "self-development", "happiness". Pick the best fit. "self-development" covers mindfulness, learning, career growth, and personal skills. "happiness" covers career satisfaction, leisure, hobbies, and fun.
- "scheduledDate": the date in YYYY-MM-DD format if mentioned (e.g., "Tuesday" → the Tuesday of this week). Leave empty string if not mentioned.
- "startTime": suggested start time in HH:MM 24h format if time context is given (e.g., "night" → "18:00", "morning" → "09:00"). Leave empty string if not clear.
- "endTime": suggested end time in HH:MM 24h format. Estimate a reasonable duration. Leave empty string if not clear.

Time context hints: "morning" = 09:00-10:00, "afternoon" = 14:00-15:00, "evening" = 17:00-18:00, "night" = 19:00-20:00, "lunch" = 12:00-13:00.

Return a JSON object with a single key "items" containing an array of parsed task objects, one per input task, in the same order.`;

      const response = await openai.chat.completions.create({
        model: "gpt-5.2",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: tasks.map((t: string, i: number) => `${i + 1}. ${t}`).join("\n") },
        ],
        response_format: { type: "json_object" },
        temperature: 0.3,
        max_completion_tokens: 2000,
      });

      const content = response.choices[0]?.message?.content;
      if (!content) {
        return res.status(500).json({ error: "No response from AI" });
      }

      const parsed = JSON.parse(content);
      res.json(parsed);
    } catch (error) {
      console.error("Error parsing tasks with AI:", error);
      res.status(500).json({ error: "Failed to parse tasks" });
    }
  });

  // ==================== HABIT COMPLETIONS ====================

  app.get("/api/habit-completions/range/:startDate/:endDate", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { startDate, endDate } = req.params;
      const completions = await storage.getHabitCompletionsForRange(userId, startDate, endDate);
      res.json(completions);
    } catch (error) {
      console.error("Error fetching habit completions range:", error);
      res.status(500).json({ error: "Failed to fetch habit completions" });
    }
  });

  app.get("/api/habit-completions/:date", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { date } = req.params;
      const completions = await storage.getHabitCompletionsForDate(userId, date);
      res.json(completions);
    } catch (error) {
      console.error("Error fetching habit completions:", error);
      res.status(500).json({ error: "Failed to fetch habit completions" });
    }
  });

  app.post("/api/habit-completions", isAuthenticated, async (req: any, res: Response) => {
    try {
      const parsed = createHabitCompletionSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      const { habitId, date, status, completionLevel, skipReason } = parsed.data;
      const validStatus = status === "skipped" ? "skipped" : status === "minimum" ? "minimum" : "completed";
      const userHabits = await storage.getHabitsByUser(userId);
      if (!userHabits.some(h => h.id === habitId)) {
        return res.status(403).json({ error: "Habit not found" });
      }
      const completion = await storage.createHabitCompletion({ userId, habitId, date, status: validStatus, completionLevel: completionLevel ?? null, skipReason: skipReason ?? null });
      res.json(completion);
    } catch (error: any) {
      if (error?.code === "23505") {
        return res.status(409).json({ error: "Already completed" });
      }
      console.error("Error creating habit completion:", error);
      res.status(500).json({ error: "Failed to create habit completion" });
    }
  });

  app.patch("/api/habit-completions/:habitId/:date", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { habitId, date } = req.params;
      const { status, completionLevel, skipReason } = req.body;
      const validStatus = status === "skipped" ? "skipped" : status === "minimum" ? "minimum" : "completed";
      await storage.updateHabitCompletionFull(userId, parseInt(habitId), date, {
        status: validStatus,
        completionLevel: completionLevel ?? null,
        skipReason: skipReason ?? null,
      });
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating habit completion:", error);
      res.status(500).json({ error: "Failed to update habit completion" });
    }
  });

  app.delete("/api/habit-completions/:habitId/:date", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { habitId, date } = req.params;
      await storage.deleteHabitCompletion(userId, parseInt(habitId), date);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting habit completion:", error);
      res.status(500).json({ error: "Failed to delete habit completion" });
    }
  });

  // ==================== MEDITATION INSIGHTS ====================

  app.get("/api/meditation-insights", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const insights = await storage.getMeditationInsightsByUser(userId);
      res.json(insights);
    } catch (error) {
      console.error("Error fetching meditation insights:", error);
      res.status(500).json({ error: "Failed to fetch insights" });
    }
  });

  app.post("/api/meditation-insights", isAuthenticated, async (req: any, res: Response) => {
    try {
      const parsed = createMeditationInsightSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      const { date, insight } = parsed.data;
      const newInsight = await storage.createMeditationInsight({ userId, date, insight });
      res.json(newInsight);
    } catch (error) {
      console.error("Error creating meditation insight:", error);
      res.status(500).json({ error: "Failed to save insight" });
    }
  });

  app.delete("/api/meditation-insights/:id", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const existing = await storage.getMeditationInsightsByUser(userId);
      const record = existing.find(r => r.id === parseInt(id));
      if (!record) {
        return res.status(403).json({ error: "Not authorized" });
      }
      await storage.deleteMeditationInsight(parseInt(id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting meditation insight:", error);
      res.status(500).json({ error: "Failed to delete insight" });
    }
  });

  // ==================== IDENTITY DOCUMENT ====================

  app.get("/api/identity-document", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const doc = await storage.getIdentityDocument(userId);
      res.json(doc || { userId, identity: "", vision: "", values: "", yearVision: "", yearVisualization: "", purpose: "", todayValue: "", todayIntention: "", todayReflection: "" });
    } catch (error) {
      console.error("Error fetching identity document:", error);
      res.status(500).json({ error: "Failed to fetch identity document" });
    }
  });

  app.put("/api/identity-document", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { identity, vision, values, yearVision, yearVisualization, purpose, todayValue, todayIntention, todayReflection, visionBoardMain, visionBoardLeft, visionBoardRight, othersWillSee, beYourself } = req.body;
      const doc = await storage.upsertIdentityDocument({
        userId,
        identity: identity || "",
        vision: vision || "",
        values: values || "",
        yearVision: yearVision ?? "",
        yearVisualization: yearVisualization ?? "",
        purpose: purpose ?? "",
        todayValue: todayValue || "",
        todayIntention: todayIntention ?? "",
        todayReflection: todayReflection ?? "",
        visionBoardMain: visionBoardMain ?? "",
        visionBoardLeft: visionBoardLeft ?? "",
        visionBoardRight: visionBoardRight ?? "",
        othersWillSee: othersWillSee ?? "",
        beYourself: beYourself ?? "",
      });
      res.json(doc);
    } catch (error) {
      console.error("Error saving identity document:", error);
      res.status(500).json({ error: "Failed to save identity document" });
    }
  });

  app.put("/api/vision-board", isAuthenticated, async (req: any, res: Response) => {
    try {
      const parsed = visionBoardSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      const { slot, imageData } = parsed.data;
      const existing = await storage.getIdentityDocument(userId);
      const updates: any = {
        userId,
        identity: existing?.identity || "",
        vision: existing?.vision || "",
        values: existing?.values || "",
        yearVision: existing?.yearVision ?? "",
        yearVisualization: existing?.yearVisualization ?? "",
        purpose: existing?.purpose ?? "",
        todayValue: existing?.todayValue || "",
        todayIntention: existing?.todayIntention ?? "",
        todayReflection: existing?.todayReflection ?? "",
        visionBoardMain: existing?.visionBoardMain ?? "",
        visionBoardLeft: existing?.visionBoardLeft ?? "",
        visionBoardRight: existing?.visionBoardRight ?? "",
        othersWillSee: existing?.othersWillSee ?? "",
        beYourself: existing?.beYourself ?? "",
      };
      if (slot === "main") updates.visionBoardMain = imageData || "";
      if (slot === "left") updates.visionBoardLeft = imageData || "";
      if (slot === "right") updates.visionBoardRight = imageData || "";
      const doc = await storage.upsertIdentityDocument(updates);
      res.json({ success: true, slot });
    } catch (error) {
      console.error("Error saving vision board:", error);
      res.status(500).json({ error: "Failed to save vision board image" });
    }
  });

  // ==================== MONTHLY GOALS ====================

  app.get("/api/monthly-goal", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const monthKey = (req.query.month as string) || format(new Date(), "yyyy-MM");
      const goal = await storage.getMonthlyGoal(userId, monthKey);
      res.json(goal || { userId, monthKey, goalStatement: "", successMarker: "", value: "", why: "", nextConcreteStep: "", prize: "", strengths: "", advantage: "", goalWhat: "", goalWhen: "", goalWhere: "", goalHow: "", blockingHabit: "", habitAddress: "", fun: "", deadline: "", successProof: "", proofMetric: "", weeklyBehavior: "", bestResult: "", innerObstacle: "", obstacleTrigger: "", obstacleThought: "", obstacleEmotion: "", obstacleBehavior: "", ifThenPlan1: "", ifThenPlan2: "" });
    } catch (error) {
      console.error("Error fetching monthly goal:", error);
      res.status(500).json({ error: "Failed to fetch monthly goal" });
    }
  });

  app.put("/api/monthly-goal", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { monthKey, goalStatement, successMarker, value, why, nextConcreteStep, prize,
        strengths, advantage, goalWhat, goalWhen, goalWhere, goalHow, blockingHabit, habitAddress, fun, deadline,
        successProof, proofMetric, weeklyBehavior, bestResult, innerObstacle, obstacleTrigger, obstacleThought, obstacleEmotion, obstacleBehavior, ifThenPlan1, ifThenPlan2 } = req.body;
      const goal = await storage.upsertMonthlyGoal({
        userId,
        monthKey: monthKey || format(new Date(), "yyyy-MM"),
        goalStatement: goalStatement || "",
        successMarker: successMarker ?? "",
        value: value ?? "",
        why: why ?? "",
        nextConcreteStep: nextConcreteStep || "",
        prize: prize ?? "",
        strengths: strengths ?? "",
        advantage: advantage ?? "",
        goalWhat: goalWhat ?? "",
        goalWhen: goalWhen ?? "",
        goalWhere: goalWhere ?? "",
        goalHow: goalHow ?? "",
        blockingHabit: blockingHabit ?? "",
        habitAddress: habitAddress ?? "",
        fun: fun ?? "",
        deadline: deadline ?? "",
        successProof: successProof ?? "",
        proofMetric: proofMetric ?? "",
        weeklyBehavior: weeklyBehavior ?? "",
        bestResult: bestResult ?? "",
        innerObstacle: innerObstacle ?? "",
        obstacleTrigger: obstacleTrigger ?? "",
        obstacleThought: obstacleThought ?? "",
        obstacleEmotion: obstacleEmotion ?? "",
        obstacleBehavior: obstacleBehavior ?? "",
        ifThenPlan1: ifThenPlan1 ?? "",
        ifThenPlan2: ifThenPlan2 ?? "",
      });
      res.json(goal);
    } catch (error) {
      console.error("Error saving monthly goal:", error);
      res.status(500).json({ error: "Failed to save monthly goal" });
    }
  });

  // ==================== PLAN VERSIONS ====================

  app.get("/api/plan-versions", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const versions = await storage.getPlanVersionsByUser(userId);
      res.json(versions);
    } catch (error) {
      console.error("Error fetching plan versions:", error);
      res.status(500).json({ error: "Failed to fetch plan versions" });
    }
  });

  app.post("/api/plan-versions/save", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { mode, versionName } = req.body;
      const currentMonth = format(new Date(), "yyyy-MM");

      const identityDoc = await storage.getIdentityDocument(userId);
      const monthlyGoal = await storage.getMonthlyGoal(userId, currentMonth);
      const allHabits = await storage.getHabitsByUser(userId);
      const activeHabits = allHabits.filter(h => h.active);

      const snapshot = {
        identityDoc: identityDoc || null,
        monthlyGoal: monthlyGoal || null,
        habits: activeHabits,
        savedAt: new Date().toISOString(),
      };

      const name = versionName || `Plan Version ${format(new Date(), "yyyy-MM-dd")}`;
      const version = await storage.createPlanVersion({
        userId,
        versionName: name,
        effectiveDate: format(new Date(), "yyyy-MM-dd"),
        data: snapshot,
      });

      if (mode === "save_and_clear" || mode === "save_and_copy") {
        if (mode === "save_and_clear") {
          await storage.clearUserPlanData(userId, currentMonth);
        }
      }

      res.json(version);
    } catch (error) {
      console.error("Error saving plan version:", error);
      res.status(500).json({ error: "Failed to save plan version" });
    }
  });

  app.post("/api/plan-versions/:id/restore", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const versions = await storage.getPlanVersionsByUser(userId);
      const version = versions.find(v => v.id === parseInt(id));
      if (!version) {
        return res.status(404).json({ error: "Version not found" });
      }

      const snapshot = version.data as any;

      if (snapshot.identityDoc) {
        await storage.upsertIdentityDocument({
          userId,
          identity: snapshot.identityDoc.identity || "",
          vision: snapshot.identityDoc.vision || "",
          values: snapshot.identityDoc.values || "",
          yearVision: snapshot.identityDoc.yearVision || "",
          yearVisualization: snapshot.identityDoc.yearVisualization || "",
          visionBoardMain: snapshot.identityDoc.visionBoardMain || "",
          visionBoardLeft: snapshot.identityDoc.visionBoardLeft || "",
          visionBoardRight: snapshot.identityDoc.visionBoardRight || "",
          purpose: snapshot.identityDoc.purpose || "",
          todayValue: snapshot.identityDoc.todayValue || "",
          todayIntention: snapshot.identityDoc.todayIntention || "",
          todayReflection: snapshot.identityDoc.todayReflection || "",
          othersWillSee: snapshot.identityDoc.othersWillSee || "",
          beYourself: snapshot.identityDoc.beYourself || "",
        });
      }

      if (snapshot.monthlyGoal) {
        const mg = snapshot.monthlyGoal;
        await storage.upsertMonthlyGoal({
          userId, monthKey: mg.monthKey,
          goalStatement: mg.goalStatement || "", successMarker: mg.successMarker ?? "", value: mg.value ?? "",
          why: mg.why ?? "", nextConcreteStep: mg.nextConcreteStep || "", prize: mg.prize ?? "",
          strengths: mg.strengths ?? "", advantage: mg.advantage ?? "", goalWhat: mg.goalWhat ?? "",
          goalWhen: mg.goalWhen ?? "", goalWhere: mg.goalWhere ?? "", goalHow: mg.goalHow ?? "",
          blockingHabit: mg.blockingHabit ?? "", habitAddress: mg.habitAddress ?? "", fun: mg.fun ?? "",
          deadline: mg.deadline ?? "", successProof: mg.successProof ?? "", proofMetric: mg.proofMetric ?? "",
          weeklyBehavior: mg.weeklyBehavior ?? "", bestResult: mg.bestResult ?? "",
          innerObstacle: mg.innerObstacle ?? "", obstacleTrigger: mg.obstacleTrigger ?? "",
          obstacleThought: mg.obstacleThought ?? "", obstacleEmotion: mg.obstacleEmotion ?? "",
          obstacleBehavior: mg.obstacleBehavior ?? "", ifThenPlan1: mg.ifThenPlan1 ?? "", ifThenPlan2: mg.ifThenPlan2 ?? "",
        });
      }

      if (snapshot.habits && Array.isArray(snapshot.habits)) {
        const currentHabits = await storage.getHabitsByUser(userId);
        const activeNames = new Set(currentHabits.filter(h => h.active).map(h => h.name.toLowerCase()));

        for (const h of snapshot.habits) {
          const name = (h.name || "").trim();
          if (!name || activeNames.has(name.toLowerCase())) continue;

          await storage.createHabit({
            userId, name, category: h.category || "health",
            habitType: h.habitType || "maintenance", timing: h.timing || "afternoon",
            cadence: h.cadence, recurring: h.recurring || "indefinite",
            duration: h.duration, startTime: h.startTime, endTime: h.endTime,
            time: h.time, motivatingReason: h.motivatingReason,
            intervalWeeks: h.intervalWeeks || 1, startDate: h.startDate, endDate: h.endDate,
            active: true,
          });
          activeNames.add(name.toLowerCase());
        }
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Error restoring plan version:", error);
      res.status(500).json({ error: "Failed to restore plan version" });
    }
  });

  app.post("/api/plan-versions/clear", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const currentMonth = format(new Date(), "yyyy-MM");
      await storage.clearUserPlanData(userId, currentMonth);
      res.json({ success: true });
    } catch (error) {
      console.error("Error clearing plan data:", error);
      res.status(500).json({ error: "Failed to clear plan data" });
    }
  });

  app.delete("/api/plan-versions/:id", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const existing = await storage.getPlanVersionsByUser(userId);
      const record = existing.find(r => r.id === parseInt(id));
      if (!record) {
        return res.status(403).json({ error: "Not authorized" });
      }
      await storage.deletePlanVersion(parseInt(id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting plan version:", error);
      res.status(500).json({ error: "Failed to delete plan version" });
    }
  });

  // ==================== TOOL USAGE LOGS ====================

  app.get("/api/tool-usage", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { startDate, endDate } = req.query;
      let logs;
      if (startDate && endDate) {
        logs = await storage.getToolUsageLogsForRange(userId, startDate as string, endDate as string);
      } else {
        logs = await storage.getToolUsageLogsByUser(userId);
      }
      res.json(logs);
    } catch (error) {
      console.error("Error fetching tool usage logs:", error);
      res.status(500).json({ error: "Failed to fetch tool usage logs" });
    }
  });

  app.post("/api/tool-usage", isAuthenticated, async (req: any, res: Response) => {
    try {
      const parsed = createToolUsageSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      const log = await storage.createToolUsageLog({ ...parsed.data, userId });
      res.json(log);
    } catch (error) {
      console.error("Error creating tool usage log:", error);
      res.status(500).json({ error: "Failed to create tool usage log" });
    }
  });

  app.patch("/api/tool-usage/:id", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const logs = await storage.getToolUsageLogsByUser(userId);
      const log = logs.find(l => l.id === parseInt(id));
      if (!log) {
        return res.status(404).json({ error: "Tool usage log not found" });
      }
      const parsedBody = updateToolUsageSchema.safeParse(req.body);
      if (!parsedBody.success) {
        return res.status(400).json({ error: parsedBody.error.issues[0].message });
      }
      const updated = await storage.updateToolUsageLog(parseInt(id), parsedBody.data);
      res.json(updated);
    } catch (error) {
      console.error("Error updating tool usage log:", error);
      res.status(500).json({ error: "Failed to update tool usage log" });
    }
  });

  app.get("/api/tool-usage/export", isAuthenticated, exportRateLimit, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { startDate, endDate } = req.query;
      let logs;
      if (startDate && endDate) {
        logs = await storage.getToolUsageLogsForRange(userId, startDate as string, endDate as string);
      } else {
        logs = await storage.getToolUsageLogsByUser(userId);
      }
      const csvHeader = "Date,Tool,Mood Before,Emotion Before,Mood After,Emotion After,Completed\n";
      const csvRows = logs.map(l =>
        `${l.date},${l.toolName},${l.moodBefore},${l.emotionBefore},${l.moodAfter ?? ""},${l.emotionAfter ?? ""},${l.completed}`
      ).join("\n");
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=tool-usage.csv");
      res.send(csvHeader + csvRows);
    } catch (error) {
      console.error("Error exporting tool usage logs:", error);
      res.status(500).json({ error: "Failed to export tool usage logs" });
    }
  });

  // ==================== CUSTOM TOOLS ====================

  app.get("/api/custom-tools", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const tools = await storage.getCustomToolsByUser(userId);
      res.json(tools);
    } catch (error) {
      console.error("Error fetching custom tools:", error);
      res.status(500).json({ error: "Failed to fetch custom tools" });
    }
  });

  app.post("/api/custom-tools", isAuthenticated, async (req: any, res: Response) => {
    try {
      const parsed = createCustomToolSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      const { name } = parsed.data;
      if (!name || !name.trim()) {
        return res.status(400).json({ error: "Tool name is required" });
      }
      const existing = await storage.getCustomToolsByUser(userId);
      const activeCount = existing.filter(t => t.active).length;
      if (activeCount >= 3) {
        return res.status(400).json({ error: "Maximum 3 active custom tools allowed. Deactivate one first." });
      }
      const duplicate = existing.find(t => t.active && t.name.toLowerCase() === name.trim().toLowerCase());
      if (duplicate) {
        return res.status(409).json({ error: "A tool with this name already exists" });
      }
      const tool = await storage.createCustomTool({ ...parsed.data, userId });
      res.json(tool);
    } catch (error) {
      console.error("Error creating custom tool:", error);
      res.status(500).json({ error: "Failed to create custom tool" });
    }
  });

  app.patch("/api/custom-tools/:id", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const tools = await storage.getCustomToolsByUser(userId);
      const tool = tools.find(t => t.id === parseInt(id));
      if (!tool) {
        return res.status(404).json({ error: "Custom tool not found" });
      }
      const parsedBody = updateCustomToolSchema.safeParse(req.body);
      if (!parsedBody.success) {
        return res.status(400).json({ error: parsedBody.error.issues[0].message });
      }
      const updated = await storage.updateCustomTool(parseInt(id), parsedBody.data);
      res.json(updated);
    } catch (error) {
      console.error("Error updating custom tool:", error);
      res.status(500).json({ error: "Failed to update custom tool" });
    }
  });

  app.delete("/api/custom-tools/:id", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const tools = await storage.getCustomToolsByUser(userId);
      const tool = tools.find(t => t.id === parseInt(id));
      if (!tool) {
        return res.status(404).json({ error: "Custom tool not found" });
      }
      await storage.deleteCustomTool(parseInt(id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting custom tool:", error);
      res.status(500).json({ error: "Failed to delete custom tool" });
    }
  });

  // ==================== PHASE 3 - TRANSFORMATION AGENT ====================
  
  app.post("/api/phase3/analyze", isAuthenticated, aiRateLimit, async (req: any, res: Response) => {
    try {
      const parsed = phase3AnalyzeSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      const { documentText } = parsed.data;

      const hasAccess = await storage.hasCourseAccess(userId, "phase3");
      if (!hasAccess) {
        return res.status(403).json({ error: "Phase 3 access required" });
      }

      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");

      const stream = await openai.chat.completions.create({
        model: "gpt-5.2",
        messages: [
          {
            role: "system",
            content: `You are an expert in behavioral psychology, personal development, and pattern recognition. 
The user will share their self-discovery documents (journal entries, GPT conversation outputs, personal reflections).

Your task is to:
1. **Identify Core Patterns**: Find recurring themes, beliefs, behaviors, and emotional patterns across the text.
2. **Highlight Strengths**: Identify positive patterns, growth areas, and inherent strengths.
3. **Surface Blind Spots**: Gently point out patterns the person may not be aware of.
4. **Map Belief Systems**: Identify core beliefs (both empowering and limiting) that drive behavior.
5. **Provide Transformation Roadmap**: Give specific, actionable steps to transform limiting patterns.
6. **Create Identity Summary**: Summarize who this person is based on the data - their values, motivations, fears, and aspirations.

Format your response as a comprehensive transformation report with clear sections and practical insights.
Be compassionate but honest. Use evidence from their text to support your observations.`
          },
          {
            role: "user",
            content: `Please analyze the following self-discovery documents and create my transformation report:\n\n${documentText}`
          }
        ],
        stream: true,
        max_completion_tokens: 4096,
      });

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || "";
        if (content) {
          res.write(`data: ${JSON.stringify({ content })}\n\n`);
        }
      }

      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
    } catch (error) {
      console.error("Phase 3 analysis error:", error);
      if (res.headersSent) {
        res.write(`data: ${JSON.stringify({ error: "Analysis failed" })}\n\n`);
        res.end();
      } else {
        res.status(500).json({ error: "Failed to analyze document" });
      }
    }
  });

  // ==================== TASKS ====================
  
  app.get("/api/tasks", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const tasks = await storage.getTasksByUser(userId);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ error: "Failed to fetch tasks" });
    }
  });

  app.get("/api/tasks/date/:date", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { date } = req.params;
      const tasks = await storage.getTasksForDate(userId, date);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks for date:", error);
      res.status(500).json({ error: "Failed to fetch tasks" });
    }
  });

  app.post("/api/tasks", isAuthenticated, async (req: any, res: Response) => {
    try {
      const parsed = createTaskSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      const { date } = parsed.data;
      
      const existingTasks = await storage.getTasksForDate(userId, date);
      if (existingTasks.length >= 3) {
        return res.status(400).json({ error: "Maximum 3 tasks per day allowed" });
      }

      const title = parsed.data.title;
      if (title && existingTasks.some(t => t.title.toLowerCase() === title.toLowerCase())) {
        return res.status(409).json({ error: `You already have a task named "${title}" on this date` });
      }

      const task = await storage.createTask({ userId, ...parsed.data });
      res.json(task);
    } catch (error) {
      console.error("Error creating task:", error);
      res.status(500).json({ error: "Failed to create task" });
    }
  });

  app.patch("/api/tasks/:id", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const existing = await storage.getTasksByUser(userId);
      const record = existing.find(r => r.id === parseInt(id));
      if (!record) {
        return res.status(403).json({ error: "Not authorized" });
      }
      const parsedBody = updateTaskSchema.safeParse(req.body);
      if (!parsedBody.success) {
        return res.status(400).json({ error: parsedBody.error.issues[0].message });
      }
      const task = await storage.updateTask(parseInt(id), parsedBody.data);
      res.json(task);
    } catch (error) {
      console.error("Error updating task:", error);
      res.status(500).json({ error: "Failed to update task" });
    }
  });

  app.delete("/api/tasks/:id", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const existing = await storage.getTasksByUser(userId);
      const record = existing.find(r => r.id === parseInt(id));
      if (!record) {
        return res.status(403).json({ error: "Not authorized" });
      }
      await storage.deleteTask(parseInt(id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting task:", error);
      res.status(500).json({ error: "Failed to delete task" });
    }
  });

  // ==================== TRIGGER LOGS ====================

  app.get("/api/trigger-logs", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const logs = await storage.getTriggerLogsByUser(userId);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching trigger logs:", error);
      res.status(500).json({ error: "Failed to fetch trigger logs" });
    }
  });

  app.post("/api/trigger-logs", isAuthenticated, async (req: any, res: Response) => {
    try {
      const parsed = createTriggerLogSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      const log = await storage.createTriggerLog({ userId, ...parsed.data });
      res.json(log);
    } catch (error) {
      console.error("Error creating trigger log:", error);
      res.status(500).json({ error: "Failed to create trigger log" });
    }
  });

  // ==================== AVOIDANCE LOGS ====================

  app.get("/api/avoidance-logs", isAuthenticated, async (req: any, res: Response) => {
    try {
      const userId = req.user.claims.sub;
      const logs = await storage.getAvoidanceLogsByUser(userId);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching avoidance logs:", error);
      res.status(500).json({ error: "Failed to fetch avoidance logs" });
    }
  });

  app.post("/api/avoidance-logs", isAuthenticated, async (req: any, res: Response) => {
    try {
      const parsed = createAvoidanceLogSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.issues[0].message });
      }
      const userId = req.user.claims.sub;
      const log = await storage.createAvoidanceLog({ userId, ...parsed.data });
      res.json(log);
    } catch (error) {
      console.error("Error creating avoidance log:", error);
      res.status(500).json({ error: "Failed to create avoidance log" });
    }
  });

  app.post("/api/audio/transcribe", isAuthenticated, transcriptionRateLimit, upload.single("audio"), async (req: any, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No audio file provided" });
      }
      const allowedMimes = ["audio/webm", "audio/wav", "audio/mp4", "audio/mpeg", "audio/ogg", "audio/flac"];
      if (!allowedMimes.includes(req.file.mimetype)) {
        fs.unlinkSync(req.file.path);
        return res.status(400).json({ error: "Unsupported audio format" });
      }
      const fileStream = fs.createReadStream(req.file.path);
      const transcription = await openai.audio.transcriptions.create({
        file: fileStream,
        model: "whisper-1",
      });
      fs.unlinkSync(req.file.path);
      res.json({ text: transcription.text });
    } catch (error) {
      console.error("Error transcribing audio:", error);
      if (req.file?.path) {
        try { fs.unlinkSync(req.file.path); } catch (_) {}
      }
      res.status(500).json({ error: "Failed to transcribe audio" });
    }
  });

  return httpServer;
}
